"""
Verify the manuscript's closed-form distance claims against exhaustive BFS.

Checks
------
G3  d(A,B) = (I + Delta)/2                      [sec. "G_3(k,n) Distance formulas"]
G3  diam    = ceil(k(n-k)/2)
G3  h(B)    = floor(Delta/2)                    [sec. "Holography Mismatch Offset h"]
G3  bounds  ceil(sum|x_i-y_i|/2) <= d(X,Y) <= sum ceil(|x_i-y_i|/2)
G4  d(A,B) = ceil(I/3) + h(B)                   [sec. "4-cycles", h >= 0 expected]
G2  d(A,B) = sum (z_i - i)                      [adjacent transpositions, sec. 7384]

Deterministic; no randomness.
"""
from collections import deque
from itertools import combinations
from math import ceil


def verts(k, n):
    """All binary words of length n with k zeros, as tuples."""
    out = []
    for zs in combinations(range(n), k):
        w = [1] * n
        for z in zs:
            w[z] = 0
        out.append(tuple(w))
    return out


def neighbors(w, cyc):
    """One cyclic rotation (both directions) of every consecutive window of length `cyc`."""
    n = len(w)
    out = set()
    for i in range(n - cyc + 1):
        blk = w[i:i + cyc]
        for rot in (blk[1:] + blk[:1], blk[-1:] + blk[:-1]):
            v = w[:i] + rot + w[i + cyc:]
            if v != w:
                out.add(v)
    return out


def bfs(src, k, n, cyc):
    dist = {src: 0}
    q = deque([src])
    while q:
        u = q.popleft()
        for v in neighbors(u, cyc):
            if v not in dist:
                dist[v] = dist[u] + 1
                q.append(v)
    return dist


def zeros(w):
    return [i + 1 for i, b in enumerate(w) if b == 0]          # 1-based


def I_of(w):
    return sum(z - i for i, z in enumerate(zeros(w), start=1))  # area


def Delta_of(w):
    s = sum((-1) ** (i + 1) * ((z - i) % 2) for i, z in enumerate(zeros(w), start=1))
    return abs(s)


def canonical(k, n):
    return tuple([0] * k + [1] * (n - k))


def check_G3(kmax=5, nmax=12):
    bad_d = bad_diam = bad_h = 0
    for n in range(3, nmax + 1):
        for k in range(1, min(kmax, n - 1) + 1):
            A = canonical(k, n)
            dist = bfs(A, k, n, 3)
            if len(dist) != len(verts(k, n)):
                print(f"  G3({k},{n}): DISCONNECTED  {len(dist)}/{len(verts(k,n))}")
            for B, d in dist.items():
                pred = (I_of(B) + Delta_of(B)) / 2
                if pred != d:
                    bad_d += 1
                    if bad_d <= 5:
                        print(f"  G3({k},{n}) B={''.join(map(str,B))}: BFS={d} formula={pred}")
                if d - ceil(I_of(B) / 2) != Delta_of(B) // 2:
                    bad_h += 1
            diam = max(dist.values())
            claim = ceil(k * (n - k) / 2)
            if diam != claim:
                bad_diam += 1
                if bad_diam <= 5:
                    print(f"  G3({k},{n}) diameter: BFS={diam} formula={claim}")
    return bad_d, bad_diam, bad_h


def check_G3_bounds(kmax=3, nmax=9):
    bad = 0
    for n in range(3, nmax + 1):
        for k in range(1, min(kmax, n - 1) + 1):
            V = verts(k, n)
            for X in V:
                dist = bfs(X, k, n, 3)
                xs = zeros(X)
                for Y, d in dist.items():
                    ys = zeros(Y)
                    lo = ceil(sum(abs(a - b) for a, b in zip(xs, ys)) / 2)
                    hi = sum(ceil(abs(a - b) / 2) for a, b in zip(xs, ys))
                    if not (lo <= d <= hi):
                        bad += 1
                        if bad <= 5:
                            print(f"  G3({k},{n}) {''.join(map(str,X))}->{''.join(map(str,Y))}: "
                                  f"{lo} <= {d} <= {hi} FAILS")
    return bad


def check_G4(kmax=5, nmax=12):
    neg_h, disc, hmax = 0, [], 0
    for n in range(4, nmax + 1):
        for k in range(1, min(kmax, n - 1) + 1):
            A = canonical(k, n)
            dist = bfs(A, k, n, 4)
            tot = len(verts(k, n))
            if len(dist) != tot:
                disc.append((k, n, len(dist), tot))
            for B, d in dist.items():
                h = d - ceil(I_of(B) / 3)
                hmax = max(hmax, h)
                if h < 0:
                    neg_h += 1
                    if neg_h <= 5:
                        print(f"  G4({k},{n}) B={''.join(map(str,B))}: d={d} < ceil(I/3)={ceil(I_of(B)/3)}")
    return neg_h, disc, hmax


def check_G2(kmax=4, nmax=10):
    bad = 0
    for n in range(2, nmax + 1):
        for k in range(1, min(kmax, n - 1) + 1):
            A = canonical(k, n)
            dist = bfs(A, k, n, 2)
            for B, d in dist.items():
                if d != I_of(B):
                    bad += 1
    return bad


if __name__ == "__main__":
    print("G3: d = (I + Delta)/2, diameter, h = floor(Delta/2)")
    bd, bdi, bh = check_G3()
    print(f"  distance mismatches : {bd}")
    print(f"  diameter mismatches : {bdi}")
    print(f"  h mismatches        : {bh}\n")

    print("G3: two-sided bounds for arbitrary X,Y")
    print(f"  violations          : {check_G3_bounds()}\n")

    print("G4: d = ceil(I/3) + h(B)")
    nh, disc, hmax = check_G4()
    print(f"  h < 0 (lower bound broken) : {nh}")
    print(f"  max h observed             : {hmax}")
    print(f"  disconnected (k,n,reached,total): {disc}\n")

    print("G2: d = sum (z_i - i)")
    print(f"  mismatches          : {check_G2()}")
