"""
Check the manuscript's claim (sec. "When Does h=2 Appear for the First Time?"):

  * every G_4(k,n) with n <= 13 has h(B) <= 1 for all B;
  * G_4(7,14) is the minimal case (by n, then k) containing h = 2;
  * exactly 6 of its 3432 vertices achieve h = 2, and its eccentricity from A is 17.

h_4(B) = d_{G_4}(A,B) - ceil(I(B)/3).
"""
from verify_distance_formulas import bfs, canonical, verts, I_of, zeros
from math import ceil

first, rows = None, []
for n in range(4, 15):
    for k in range(1, n):
        A = canonical(k, n)
        dist = bfs(A, k, n, 4)
        hs = {}
        for B, d in dist.items():
            hs.setdefault(d - ceil(I_of(B) / 3), []).append(B)
        hmax = max(hs)
        conn = len(dist) == len(verts(k, n))
        rows.append((n, k, hmax, len(hs.get(2, [])), max(dist.values()), conn))
        if hmax >= 2 and first is None:
            first = (k, n, len(hs[2]), max(dist.values()), hs[2])

print(f"{'n':>3} {'k':>3} {'max h':>6} {'#(h=2)':>7} {'ecc(A)':>7}  connected")
for n, k, hmax, c2, ecc, conn in rows:
    if hmax >= 2 or (n, k) in {(4, 1), (4, 2), (13, 6), (14, 7)}:
        print(f"{n:>3} {k:>3} {hmax:>6} {c2:>7} {ecc:>7}  {conn}")

print(f"\nmax h over all n<=13 : {max(h for n,k,h,_,_,_ in rows if n <= 13)}")
k, n, c2, ecc, ex = first
print(f"first (n,then k) with h=2 : G_4({k},{n})   vertices with h=2: {c2}   ecc(A)={ecc}")
print("the h=2 vertices:")
for B in sorted(ex):
    print("   ", "".join(map(str, B)), " zeros at", zeros(B), " I =", I_of(B))
