# Open questions

Running list of things the manuscript leaves unresolved. Add a dated entry per item;
move it to the `.tex` once it is settled.

## 2026-09-19 — seeded

- [ ] Closed form for $m(n,k)$ for general $k$ (have $k = 3,4,5,6$).
- [ ] Sharp upper bound on $h'(B)$ for $G_4(k,n)$ (the 25% bound is stated for $G_3$).
- [ ] Higher correction terms beyond $h_4(B)$ — is the concentration empirical only?

## 2026-09-19 — undefined LaTeX references (from a clean `make pdf`)

Each of these is `\ref`'d in the text but has no matching `\label` in the source.
They render as `??` in the PDF.

Equations:

- `eq:H1-k1` — line 4596
- `eq:k1` — line 7398
- `eq:k2` — lines 7371, 7382, 7398, 7411, 7414, 7478

Tables:

- `tab:k2-parity` — line 384
- `tab:mismatch-by-k` — line 481
- `tab:k5-parity` — line 777; `tab:k5-families` — line 804
- `tab:k6-parity` — line 953; `tab:k6-families` — line 988
- `tab:h-values` — line 1183
- `tab:m2formula`, `tab:m2graph` — lines 1286, 1287

Section:

- `subsec:k3-open` — line 7357
